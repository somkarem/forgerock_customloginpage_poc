# Non-JavaScript Login

An example NodeJS app which uses server-side methods to call AM and render static (non-javascript) client HTML.

The set of supported of callbacks is:

- NameCallback
- ValidatedCreateUsernameCallback
- StringAttributeInputCallback
- PasswordCallback
- ValidatedCreatePasswordCallback
- BooleanAttributeInputCallback
- ChoiceCallback


This example also follows UK Government GDS branding styles.

## Install and setup

Clone this repo.

Install node modules:

```npm install```

Edit the top-level config.json and set suitable values for AM host, realm name, and default login tree.

```
{
    "AM": "https://openam-forgerock-jknight.forgeblocks.com/am/",
    "REALM": "/alpha",
    "LOGINTREE": "Login",
    "REGTREE": "Registration"
}
```

## Run

```node bin/www```

Then browse to http://localhost:8081/

# DISCLAIMER: 

The sample code described herein is provided on an "as is" basis, without warranty of any kind, to the fullest extent permitted by law. ForgeRock does not warrant or guarantee the individual success developers may have in implementing the sample code on their development platforms or in production configurations.

ForgeRock does not warrant, guarantee or make any representations regarding the use, results of use, accuracy, timeliness or completeness of any data or information relating to the sample code. ForgeRock disclaims all warranties, expressed or implied, and in particular, disclaims all warranties of merchantability, and warranties related to the code, or any service or software related thereto.

ForgeRock shall not be liable for any direct, indirect or consequential damages or costs of any type arising out of any action taken by you or others related to the sample code.
