var express = require('express');
var router = express.Router();
var request = require('request');
var expressSession = require('express-session');

var config = require('../config.json');



// Call AM authenticate endpoint with requested tree and the current authn state
// Returns promise for handling the response or error
// 
function authenticate(tree, body) {
    return new Promise(function(resolve,reject) {
        var options = {
            url: config.AM + 'json/realms/root/realms' + config.REALM + '/authenticate?authIndexType=service&authIndexValue=' + tree,
            method: 'POST',
            body: body,
            headers: { 
                'Content-Type':'application/json',
                'X-Requested-With': 'XmlHttpRequest'
            },
            json: true
        }
        // console.log("AUTHN REQUEST: " + JSON.stringify(body));
        request(options, function (error, response, body) {
            // console.log("AUTHN RESPONSE: " + JSON.stringify(body));
            if (!error && response.statusCode == 200) resolve(body);
            else reject(error);
        });
    });
}



// Creates a simplified version of the callback array which can be more easily interpretted by handlebars
//
function handleCallbacks(incoming) {
    var callbacks = [];
    for (var i=0; i < incoming.length; i++) {
        cb = { counter: "input_" + i};
        cb[incoming[i].type] = true;
        for (var j=0; j < incoming[i].output.length; j++)
            if (incoming[i].output[j].name == "prompt") cb["prompt"] = incoming[i].output[j].value;
        if (incoming[i].type == "ChoiceCallback") {
            for (var j=0; j < incoming[i].output.length; j++)
                if (incoming[i].output[j].name == "choices") cb["choices"] = incoming[i].output[j].value;   
        }
        callbacks.push(cb);
    };
    return callbacks;
}



// Renders initial home page
//
router.get('/', function (req, res, next) {
    res.render('home', { logintree: config.LOGINTREE, regtree: config.REGTREE});
});



// Handles initial stage of a login request.
// 
router.get('/login', function (req, res, next) {
    if (req.query.hasOwnProperty("service")) req.session.tree = req.query.service;
    else req.session.tree = config.LOGINTREE;

    authenticate(req.session.tree, null).then(function(body){
        var callbacks = handleCallbacks(body.callbacks);
        req.session.data = body;
        res.render('home', { login:true, header: body.header, callbacks: callbacks });
    }, function(error){ res.render('home', { failure:true }); })
});



// Handles subsequent authn stages (POST requests from the filled in HTML form)
//
router.post('/login', function (req, res, next) {
    // Populate the original callback array with user's form values
    // BooleanAttributeInput and Choice callbacks need a bit of processing to retrieve the correct value
    for (var i=0; i<req.session.data.callbacks.length; i++) {
        var callback = req.session.data.callbacks[i];
        if (callback.type == "BooleanAttributeInputCallback") {
            if (req.body["input_" + i]) callback.input[0].value = true;
        } else if (callback.type == "ChoiceCallback") {
            for (var j=0; j < callback.output.length; j++)
                if (callback.output[j].name == "choices") 
                    for (var k=0; k < callback.output[j].value.length; k++) {
                        if (req.body["input_" + i] == callback.output[j].value[k]) callback.input[0].value = k;
                    }
        } else callback.input[0].value = req.body["input_" + i];
    };

    // Call authn to handle next steps
    authenticate(req.session.tree, req.session.data).then(function(body) {
        if (body.hasOwnProperty("tokenId")) {
            // If "tokenId" is present then login completed successfully
            res.render('home', { success:true });
        } else {
            // Otherwise continue handling callbacks
            var callbacks = handleCallbacks(body.callbacks);
            req.session.data = body;
            res.render('home', { login:true, header: body.header, callbacks: callbacks });
        }
    }, function(error) { res.render('home', { failure:true }); });

});



router.get('/denied', function (req, res, next) {
    console.log(JSON.stringify(req.headers));
    res.render('home/denied', {title: config.translations.title});
});

module.exports = router;